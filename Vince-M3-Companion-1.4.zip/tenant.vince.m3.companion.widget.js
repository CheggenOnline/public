System.register(['@angular/common', '@angular/core', '@angular/forms', '@angular/platform-browser', 'lime'], (function (exports) {
    'use strict';
    var CommonModule, Input, ViewChild, Component, Inject, NgModule, ElementRef, FormsModule, DomSanitizer, widgetContextInjectionToken, Log, WidgetState, IWidgetInstance, IWidgetContext;
    return {
        setters: [function (module) {
            CommonModule = module.CommonModule;
        }, function (module) {
            Input = module.Input;
            ViewChild = module.ViewChild;
            Component = module.Component;
            Inject = module.Inject;
            NgModule = module.NgModule;
            ElementRef = module.ElementRef;
        }, function (module) {
            FormsModule = module.FormsModule;
        }, function (module) {
            DomSanitizer = module.DomSanitizer;
        }, function (module) {
            widgetContextInjectionToken = module.widgetContextInjectionToken;
            Log = module.Log;
            WidgetState = module.WidgetState;
            IWidgetInstance = module.IWidgetInstance;
            IWidgetContext = module.IWidgetContext;
        }],
        execute: (function () {

            /******************************************************************************
            Copyright (c) Microsoft Corporation.

            Permission to use, copy, modify, and/or distribute this software for any
            purpose with or without fee is hereby granted.

            THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
            REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
            AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
            INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
            LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
            OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
            PERFORMANCE OF THIS SOFTWARE.
            ***************************************************************************** */
            /* global Reflect, Promise */


            function __decorate(decorators, target, key, desc) {
                var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
                if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
                else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
                return c > 3 && r && Object.defineProperty(target, key, r), r;
            }

            function __param(paramIndex, decorator) {
                return function (target, key) { decorator(target, key, paramIndex); }
            }

            function __metadata(metadataKey, metadataValue) {
                if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
            }

/* Vince host navigation receiver. Transport and canonical bookmark policy are explicit. */
function createM3NavigationHost(options) {
    'use strict';
    const protocol = 'vince.m3.navigation';
    const version = 2;
    const cache = new Map();
    const dispatchTimes = [];
    let sessionId = options.uuid();
    let destroyed = false;
    let handshakeId = null;
    const now = options.now || Date.now;
    function response(type, requestId, fields) {
        return Object.assign({ protocol, version, type, requestId, sessionId }, fields || {});
    }
    function send(data) { if (!destroyed) options.send(data); }
    function error(requestId, code, message) {
        send(response('protocol.error', requestId, { error: { code, message } }));
    }
    function plain(value) { return value !== null && typeof value === 'object' && !Array.isArray(value); }
    function keys(value, allowed) { return Object.keys(value).every(key => allowed.includes(key)); }
    function receive(event) {
        if (destroyed || !options.isTrusted(event)) return;
        let payload;
        try {
            if (JSON.stringify(event.data).length > 16384) return;
            payload = options.unwrap(event.data);
        } catch (_) { return; }
        if (!plain(payload) || payload.protocol !== protocol) return;
        if (typeof payload.requestId !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(payload.requestId)) return;
        if (payload.version !== version) return error(payload.requestId, 'UNSUPPORTED_VERSION', 'Unsupported navigation protocol version.');
        if (payload.type === 'capabilities.request') {
            if (!keys(payload, ['protocol', 'version', 'type', 'requestId'])) return error(payload.requestId, 'INVALID_REQUEST', 'Invalid capability request.');
            // New document/client handshakes establish a fresh session; duplicate handshake is stable.
            if (handshakeId !== payload.requestId) {
                cache.clear();
                sessionId = options.uuid();
                handshakeId = payload.requestId;
            }
            const available = options.available();
            return send(response('capabilities.result', payload.requestId, {
                capabilities: { navigate: available, modes: available ? ['list', 'display', 'start', 'change'] : [],
                    targetProfiles: available ? (typeof options.targetProfiles === 'function' ? options.targetProfiles() : ['customer.main.display', 'customer.addresses.list', 'orders.program.start', 'item.program.list']) : [],
                    targetScopeModes: available && typeof options.targetScopeModes === 'function' ? options.targetScopeModes() : {},
                    completionSignal: 'dispatched' }
            }));
        }
        if (payload.type !== 'navigate.request' || !keys(payload, ['protocol', 'version', 'type', 'requestId', 'sessionId', 'target', 'bookmark', 'label'])) {
            return error(payload.requestId, 'INVALID_REQUEST', 'Invalid navigation request.');
        }
        if (payload.sessionId !== sessionId) return error(payload.requestId, 'STALE_SESSION', 'Repeat the capability handshake.');
        const fingerprint = JSON.stringify(payload);
        for (const [key, value] of cache) if (value.expires <= now()) cache.delete(key);
        const cached = cache.get(payload.requestId);
        if (cached) {
            if (cached.fingerprint !== fingerprint) return error(payload.requestId, 'REQUEST_ID_CONFLICT', 'Request ID was already used for different content.');
            return send(cached.result || cached.ack);
        }
        if (!options.available()) return error(payload.requestId, 'HOST_NOT_READY', 'Host navigation is unavailable.');
        const validation = options.validate(payload);
        if (!validation.ok) return error(payload.requestId, validation.code || 'INVALID_REQUEST', validation.message || 'Navigation request rejected.');
        while (dispatchTimes.length && dispatchTimes[0] <= now() - 60000) dispatchTimes.shift();
        if (dispatchTimes.length >= 10 || cache.size >= 100) return error(payload.requestId, 'RATE_LIMITED', 'Too many navigation requests; wait before trying again.');
        dispatchTimes.push(now());
        const ack = response('navigate.ack', payload.requestId, { status: 'accepted' });
        const entry = { fingerprint, ack, expires: now() + 300000 };
        cache.set(payload.requestId, entry);
        send(ack);
        // SDK launch returns void: only dispatch can be acknowledged, never panel-open success.
        try {
            options.launch(payload.bookmark);
            entry.result = response('navigate.result', payload.requestId, {
                status: 'dispatched', target: { profile: payload.target.profile, program: payload.target.program }
            });
        } catch (_) {
            entry.result = response('navigate.result', payload.requestId, {
                status: 'failed',
                error: { code: 'NAVIGATION_FAILED', message: 'The host could not dispatch this bookmark.' }
            });
        }
        send(entry.result);
    }
    return {
        receive,
        reset() { cache.clear(); handshakeId = null; sessionId = options.uuid(); },
        destroy() { destroyed = true; cache.clear(); dispatchTimes.length = 0; }
    };
}

/* Validate app-built bookmarks against the two observed, read-only native templates. */
function createBookmarkPolicy(getContext) {
    // Native program start accepts only a code, never caller-defined URL/options.
    const logicalId = 'lid://infor.m3.m3';
    const profiles = {
        'program.start': { mode:'start' },
        'customer.record.display': { program:'CRS610', mode:'display', scopeMode:'company' },
        'customer.record.change': { program:'CRS610', mode:'change', scopeMode:'company' },
        'customer.record.addresses': { program:'OIS002', mode:'list', scopeMode:'company' },
        'item.program.list': { program:'MMS001', mode:'list' },
        'orders.program.start': { program:'OIS100', mode:'start' },
        'customer.main.display': { program: 'CRS610', mode: 'display' },
        'customer.addresses.list': { program: 'OIS002', mode: 'list' }
    };
    const plain = x => x !== null && typeof x === 'object' && !Array.isArray(x);
    const keys = (x, allowed) => Object.keys(x).every(k => allowed.includes(k));
    function validCustomer(value) {
        if (typeof value !== 'string' || value.length < 1 || value.length > 10 || !value.trim() || /[,+\u0000-\u001f\u007f-\u009f]/.test(value)) return false;
        try { encodeURIComponent(value); return true; } catch (_) { return false; }
    }
    function programScope(context, recordsKey) {
        if (!context || context.visible === false || context.recordsTruncated === true) return null;
        const session = context.session || {}, companies = [], divisions = [];
        for (const k of ['cono','CONO','company']) if (Object.prototype.hasOwnProperty.call(session,k)) {
            if (!['string','number'].includes(typeof session[k]) || !/^\d{1,3}$/.test(String(session[k]))) return null;
            companies.push(String(session[k]));
        }
        for (const k of ['divi','DIVI','division']) if (Object.prototype.hasOwnProperty.call(session,k)) {
            if (typeof session[k] !== 'string' || !/^[A-Za-z0-9]{0,3}$/.test(session[k])) return null;
            divisions.push(session[k]);
        }
        const records = context[recordsKey];
        if (records !== undefined && !Array.isArray(records)) return null;
        for (const e of records || []) {
            if (!e || e.visible === false || e.accountingEntity === undefined) continue;
            if (typeof e.accountingEntity !== 'string') return null;
            const m = e.accountingEntity.match(/^(\d{1,3})_([A-Za-z0-9]{1,3})$/);
            if (!m) return null;
            companies.push(m[1]); divisions.push(m[2]);
        }
        if (!companies.length || !divisions.length || new Set(companies).size !== 1 || new Set(divisions).size !== 1) return null;
        return {company:companies[0],division:divisions[0]};
    }
    function companyScope(context) {
        if (!context || context.visible === false || context.recordsTruncated === true) return null;
        const companies = [], session = context.session || {};
        for (const key of ['cono','CONO','company']) if (Object.prototype.hasOwnProperty.call(session,key)) {
            if (!['string','number'].includes(typeof session[key]) || !/^\d{1,3}$/.test(String(session[key]))) return null;
            companies.push(String(session[key]));
        }
        if (context.entities !== undefined && !Array.isArray(context.entities)) return null;
        for (const entity of context.entities || []) {
            if (!entity || entity.visible === false || entity.accountingEntity === undefined) continue;
            const match = typeof entity.accountingEntity === 'string' && entity.accountingEntity.match(/^(\d{1,3})_([A-Za-z0-9]{0,3})$/);
            if (!match) return null;
            companies.push(match[1]);
        }
        return companies.length && new Set(companies).size === 1 ? {company:companies[0]} : null;
    }
    function canonical(target) {
        if (target.profile === 'program.start') return '?LogicalId=' + logicalId + '&program=' + target.program;
        const c = target.parameters.CUNO;
        let bookmark;
        if (target.profile === 'item.program.list') {
            bookmark = 'bookmark?MMS001&fieldNames=WFSLCT%2C%2520%2CWTSLCT%2C%2520%2CW1OBKV%2C%2520&tableName=MITMAS&keys=MMCONO%2C' + target.company + '%2CMMITNO%2C%20&name=MMS001%2FB&description=MMS001%20Item.%20Open&includeStartPanel=True&source=MForms&requirePanel=True&startPanel=B&sortingOrder=1&view=STD01-01';
        } else if (target.profile === 'orders.program.start') {
            return '?LogicalId=' + logicalId + '&program=OIS100';
        } else if (['customer.main.display','customer.record.display','customer.record.change'].includes(target.profile)) {
            const key = 'OKCONO,' + target.company + ',OKCUNO,' + c + '+'.repeat(10-c.length);
            bookmark = 'bookmark?CRS610&OCUSMA&' + encodeURIComponent(key) + (target.profile === 'customer.record.change' ? '&2&E&' : '&5&E&') + 'CRS610%2FE&CRS610%20Customer.%20Open';
        } else {
            bookmark = 'bookmark?OIS002&fieldNames=WRADRT%2C%2520%2CWRADID%2C%2520&tableName=OCUSAD&keys=OPCONO%2C' + target.company + '%2COPCUNO%2C%2B%2COPADRT%2C%2B%2COPADID%2C%2B&name=OIS002%2FB&description=OIS002%20Customer.%20Connect%20Addresses&includeStartPanel=True&source=MForms&requirePanel=True&startPanel=B&parameters=' + encodeURIComponent('ZZCUNO,' + c);
        }
        return '?favoriteContext=' + encodeURIComponent(bookmark) + '&LogicalId=' + encodeURIComponent(logicalId);
    }
    function validate(payload) {
        const fail = (code, message) => ({ok:false,code,message});
        if (!plain(payload)) return fail('INVALID_REQUEST','Invalid request envelope.');
        const t = payload.target;
        if (plain(t) && t.profile === 'program.start') {
            if (!keys(t,['profile','program','mode','logicalId','parameters']) || t.mode !== 'start' ||
                t.logicalId !== logicalId || typeof t.program !== 'string' || !/^[A-Z]{3}\d{3}$/.test(t.program) ||
                !plain(t.parameters) || Object.keys(t.parameters).length !== 0 ||
                (payload.label !== undefined && (typeof payload.label !== 'string' || payload.label.length > 160)))
                return fail('INVALID_REQUEST','Invalid or unsupported program-start target.');
            if (!plain(payload.bookmark) || !keys(payload.bookmark,['url']) || payload.bookmark.url !== canonical(t))
                return fail('UNSUPPORTED_TARGET','Program start must use the exact deployment-approved URL.');
            return {ok:true};
        }
        // Company-keyed entity profiles are deployment metadata, never caller claims.
        const companyProfile = plain(t) && typeof t.profile === 'string' && Object.prototype.hasOwnProperty.call(profiles,t.profile) && profiles[t.profile].scopeMode === 'company' ? profiles[t.profile] : null;
        if (companyProfile) {
            if (!keys(t,['profile','program','mode','company','parameters']) || t.program !== companyProfile.program || t.mode !== companyProfile.mode ||
                typeof t.company !== 'string' || !/^\d{1,3}$/.test(t.company) || !plain(t.parameters) || !keys(t.parameters,['CUNO']) || !validCustomer(t.parameters.CUNO) ||
                (payload.label !== undefined && (typeof payload.label !== 'string' || payload.label.length > 160))) return fail('INVALID_REQUEST','Invalid company-scoped record target.');
            const scope = companyScope(getContext());
            if (!scope || scope.company !== t.company) return fail('CONTEXT_MISMATCH','Record target does not match current trusted company.');
            if (!plain(payload.bookmark) || !keys(payload.bookmark,['url']) || payload.bookmark.url !== canonical(t)) return fail('UNSUPPORTED_TARGET','Bookmark is not the exact approved entity template.');
            return {ok:true};
        }
        if (!plain(t) || !keys(t,['profile','program','mode','company','division','parameters']) || typeof t.profile!=='string' || !Object.prototype.hasOwnProperty.call(profiles,t.profile)) return fail('UNSUPPORTED_TARGET','Unsupported navigation target.');
        if (['orders.program.start','item.program.list'].includes(t.profile)) {
            if (t.program !== profiles[t.profile].program || t.mode !== profiles[t.profile].mode || (typeof t.company !== 'string' || !/^\d{1,3}$/.test(t.company)) || typeof t.division !== 'string' || !/^[A-Za-z0-9]{0,3}$/.test(t.division) || !plain(t.parameters) || Object.keys(t.parameters).length !== 0 ||
                (payload.label !== undefined && (typeof payload.label !== 'string' || payload.label.length > 160))) return fail('INVALID_REQUEST','Invalid program-start target.');
            const scope = programScope(getContext(), 'entities');
            if (!scope || scope.company !== t.company || scope.division !== t.division) return fail('CONTEXT_MISMATCH','Program start does not match current trusted company/division.');
            if (!plain(payload.bookmark) || !keys(payload.bookmark,['url']) || payload.bookmark.url !== canonical(t)) return fail('UNSUPPORTED_TARGET','Bookmark is not the exact approved program-start template.');
            return {ok:true};
        }
        const p = profiles[t.profile];
        if (p.program!==t.program || p.mode!==t.mode || typeof t.company!=='string' || !/^\d{1,3}$/.test(t.company) || typeof t.division!=='string' || !/^[A-Za-z0-9]{0,3}$/.test(t.division) || !plain(t.parameters) || !keys(t.parameters,['CUNO']) || !validCustomer(t.parameters.CUNO)) return fail('INVALID_REQUEST','Invalid read-only target fields.');
        if (payload.label!==undefined && (typeof payload.label!=='string' || payload.label.length>160)) return fail('INVALID_REQUEST','Invalid navigation label.');
        const ctx=getContext();
        if (!ctx || !Array.isArray(ctx.entities)) return fail('HOST_NOT_READY','No trusted M3 context has been received.');
        const customers=ctx.entities.filter(e=>e&&e.visible!==false&&e.entityType==='InforCustomerPartyMaster');
        const signatures=[...new Set(customers.map(e=>JSON.stringify([e.id1,e.accountingEntity])))];
        if(signatures.length!==1) return fail('CONTEXT_MISMATCH','Select one customer in M3 first.');
        const e=customers[0];
        const accounting=typeof e.accountingEntity==='string'&&e.accountingEntity.match(/^(\d{1,3})_([A-Za-z0-9]{1,3})$/);
        const session=ctx.session||{};
        const company=String(session.cono??session.CONO??session.company??(accounting&&accounting[1])??'');
        const division=String(session.divi??session.DIVI??session.division??(accounting&&accounting[2])??'');
        if ((e.accountingEntity && !accounting) || (accounting && (company!==accounting[1] || division!==accounting[2])) || !/^\d{1,3}$/.test(company) || !/^[A-Za-z0-9]{0,3}$/.test(division) || company!==t.company || division!==t.division || e.id1!==t.parameters.CUNO) return fail('CONTEXT_MISMATCH','Bookmark does not match the current M3 customer/company/division.');
        if (!plain(payload.bookmark) || !keys(payload.bookmark,['url']) || payload.bookmark.url!==canonical(t)) return fail('UNSUPPORTED_TARGET','Bookmark is not the exact approved read-only template.');
        return {ok:true};
    }
    return { validate, canonical, targetProfiles: () => Object.keys(profiles), targetScopeModes: () => Object.fromEntries(Object.entries(profiles).filter(([,p]) => p.scopeMode).map(([key,p]) => [key,p.scopeMode])) };
}

            const DEFAULT_BASE_URL = "https://vince-playground.vince.live/ai-apps/305c3beb-f835-4e7a-9486-e2302bcf24fd/run";
            const ALL_CONTEXTS_ENTITY_TYPE = "__all__";
            const ALL_CONTEXTS_LABEL = "All contexts";
            let IonApiM3Component = class IonApiM3Component {
                constructor(widgetContext, sanitizer) {
                    this.widgetContext = widgetContext;
                    this.sanitizer = sanitizer;
                    this.loadingIframe = true;
                    this.defaultBaseUrl = DEFAULT_BASE_URL;
                    this.baseEntityOptions = [];
                    this.baseUrl = this.defaultBaseUrl;
                    this.entityOptions = [];
                    this.selectedEntityType = "";
                    this.preferredEntityType = "";
                    this.url = this.baseUrl;
                    this.lastSignature = "";
                    this.applySettings();
                }
                ngOnInit() {
                    this.initializeNavigation();
                    this.setWidgetBusy(true);
                    if (this.widgetInstance) {
                        this.widgetInstance.settingsSaved = () => this.onSettingsSaved();
                    }
                    this.contextSubscription = this.widgetContext
                        .receive("inforBusinessContext")
                        .subscribe((ctx) => this.handleContext(ctx));
                }
                ngOnDestroy() {
                    if (this.contextSubscription?.unsubscribe) this.contextSubscription.unsubscribe();
                    if (this.navigationListener) window.removeEventListener('message', this.navigationListener);
                    if (this.navigationHost) this.navigationHost.destroy();
                    if (this.widgetInstance) this.widgetInstance.settingsSaved = undefined;
                }
                onIframeLoad() {
                    Log.info("[tenant.vince.m3.companion] Iframe loaded.");
                    this.postContextToIframe();
                    this.loadingIframe = false;
                    this.setWidgetBusy(false);
                }
                onIframeError() {
                    this.navigationHost?.reset();
                    Log.error("[tenant.vince.m3.companion] Iframe failed to load.");
                    this.loadingIframe = false;
                    this.setWidgetBusy(false);
                }
                onSettingsSaved() {
                    const previousEntity = this.selectedEntityType;
                    const previousPreferred = this.preferredEntityType;
                    const previousBase = this.baseUrl;
                    this.applySettings();
                    const baseChanged = this.baseUrl !== previousBase;
                    if (baseChanged) this.navigationHost?.reset();
                    const entityChanged = this.selectedEntityType !== previousEntity;
                    const preferredChanged = this.preferredEntityType !== previousPreferred;
                    if (!baseChanged && !entityChanged && !preferredChanged)
                        return;
                    this.lastSignature = "";
                    if (this.context) {
                        const nextBase = this.buildUrlFromContext(this.context);
                        if (nextBase || this.selectedEntityType === ALL_CONTEXTS_ENTITY_TYPE) {
                            Log.info("[tenant.vince.m3.companion] Context changed after settings save; posting context to current iframe without reload.");
                            this.pendingContextToPost = this.buildOutgoingContext(this.context);
                            this.postContextToIframe();
                            return;
                        }
                    }
                    this.url = this.baseUrl;
                    this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);
                }
                onEntityTypeChange(entityType) {
                    this.selectedEntityType = entityType;
                    this.lastSignature = "";
                    if (this.context) {
                        const nextBase = this.buildUrlFromContext(this.context);
                        if (nextBase || this.selectedEntityType === ALL_CONTEXTS_ENTITY_TYPE) {
                            Log.info("[tenant.vince.m3.companion] Entity selection changed; posting context to current iframe without reload.");
                            this.pendingContextToPost = this.buildOutgoingContext(this.context);
                            this.postContextToIframe();
                        }
                    }
                }
                applySettings() {
                    const settings = this.widgetContext?.getSettings?.() ?? undefined;
                    const configuredBaseUrl = typeof settings?.get === "function"
                        ? settings.get("baseUrl")
                        : settings?.baseUrl;
                    const nextBase = typeof configuredBaseUrl === "string" && configuredBaseUrl.trim()
                        ? configuredBaseUrl.trim()
                        : this.defaultBaseUrl;
                    const preferred = typeof settings?.get === "function"
                        ? settings.get("preferredEntityType") ??
                            settings.get("entityType")
                        : settings?.preferredEntityType ?? settings?.entityType;
                    this.navigationDiagnosticsEnabled = (typeof settings?.get === 'function' ? settings.get('navigationDiagnostics') : settings?.navigationDiagnostics) === true;
                    this.baseUrl = nextBase;
                    this.preferredEntityType =
                        typeof preferred === "string" ? preferred.trim() : "";
                    this.selectedEntityType = this.resolveEntityFromSettings(settings);
                    this.url = this.baseUrl;
                    this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);
                }
                updateEntityOptionsFromContext(ctx) {
                    const discovered = new Set(this.baseEntityOptions);
                    ctx?.entities
                        ?.filter((e) => e?.entityType && e.visible !== false)
                        .forEach((e) => discovered.add(e.entityType));
                    if (this.selectedEntityType) {
                        discovered.add(this.selectedEntityType);
                    }
                    const updatedOptions = Array.from(discovered);
                    this.entityOptions = updatedOptions;
                    this.persistEntityOptions(updatedOptions);
                    // Do not auto-select; selection only changes via user action.
                    return false;
                }
                persistEntityOptions(options) {
                    const settings = this.widgetContext?.getSettings?.();
                    if (settings?.set) {
                        settings.set("entityOptions", options);
                    }
                }
                resolveEntityFromSettings(settings) {
                    const configuredEntity = typeof settings?.get === "function"
                        ? settings.get("entityType")
                        : settings?.entityType;
                    if (typeof configuredEntity === "string" && configuredEntity.trim()) {
                        if (!this.entityOptions.includes(configuredEntity)) {
                            this.entityOptions = [...this.entityOptions, configuredEntity];
                        }
                        return configuredEntity;
                    }
                    return this.entityOptions[0] ?? "";
                }
                setWidgetBusy(isBusy) {
                    this.widgetContext.setState(isBusy ? WidgetState.busy : WidgetState.running);
                }
                getEntity(ctx, entityType) {
                    const entities = ctx?.entities ?? [];
                    return entities.find((entity) => entity && entity.entityType === entityType && entity.visible !== false);
                }
                normalizeM3Id(id) {
                    if (!id) {
                        return "";
                    }
                    return String(id).replace(/^&+/, "").trim();
                }
                buildUrlFromContext(ctx) {
                    const primaryEntity = this.getEntity(ctx, this.selectedEntityType);
                    const preferredEntity = this.getEntity(ctx, this.preferredEntityType);
                    const cono = ctx?.session?.cono ?? "";
                    const divi = ctx?.session?.divi ?? "";
                    const primaryIds = this.extractEntityIds(primaryEntity);
                    const preferredIds = this.preferredEntityType
                        ? this.extractEntityIds(preferredEntity)
                        : {};
                    if (Object.keys(primaryIds).length === 0 &&
                        Object.keys(preferredIds).length === 0) {
                        return null;
                    }
                    const params = new URLSearchParams();
                    if (cono)
                        params.set("cono", cono);
                    if (divi)
                        params.set("divi", divi);
                    // Primary selection
                    if (Object.keys(primaryIds).length > 0) {
                        params.set("entityType", this.selectedEntityType);
                        Object.entries(primaryIds).forEach(([key, value]) => params.set(key, value));
                        // Preserve the original item-specific param for compatibility.
                        if (this.selectedEntityType === "InforItemMaster") {
                            const itno = primaryIds.id1 || primaryIds.id2;
                            if (itno) {
                                params.set("itno", itno);
                            }
                        }
                    }
                    // Preferred selection (if distinct and present)
                    if (this.preferredEntityType &&
                        (this.preferredEntityType !== this.selectedEntityType ||
                            Object.keys(primaryIds).length === 0) &&
                        Object.keys(preferredIds).length > 0) {
                        params.set("preferredEntityType", this.preferredEntityType);
                        Object.entries(preferredIds).forEach(([key, value]) => params.set(`preferred_${key}`, value));
                        if (this.preferredEntityType === "InforItemMaster") {
                            const itnoPref = preferredIds.id1 || preferredIds.id2;
                            if (itnoPref) {
                                params.set("preferredItno", itnoPref);
                            }
                        }
                    }
                    if (ctx?.program)
                        params.set("program", ctx.program);
                    if (ctx?.screenId)
                        params.set("screenId", ctx.screenId);
                    if (ctx?.panel)
                        params.set("panel", ctx.panel);
                    return `${this.baseUrl}?${params.toString()}`;
                }
                buildOutgoingContext(ctx) {
                    if (this.selectedEntityType === ALL_CONTEXTS_ENTITY_TYPE) {
                        return ctx;
                    }
                    const matchTypes = new Set([this.selectedEntityType, this.preferredEntityType].filter(Boolean));
                    if (matchTypes.size === 0) {
                        return ctx;
                    }
                    return {
                        ...ctx,
                        entities: ctx?.entities?.filter((entity) => entity?.entityType && matchTypes.has(entity.entityType)),
                    };
                }
                handleContext(ctx) {
                    Log.info(`[tenant.vince.m3.companion] Received M3 context: ${JSON.stringify({
            program: ctx?.program,
            screenId: ctx?.screenId,
            panel: ctx?.panel,
            entityCount: ctx?.entities?.length ?? 0,
            cono: ctx?.session?.cono,
            divi: ctx?.session?.divi,
        })}`);
                    this.context = ctx;
                    this.pendingContextToPost = this.buildOutgoingContext(ctx);
                    this.postContextToIframe();
                    const selectionChanged = this.updateEntityOptionsFromContext(ctx);
                    const nextBase = this.buildUrlFromContext(ctx);
                    if (!nextBase) {
                        return;
                    }
                    const primary = this.getEntity(ctx, this.selectedEntityType);
                    const preferred = this.getEntity(ctx, this.preferredEntityType);
                    const ids = this.extractEntityIds(primary);
                    const preferredIds = this.extractEntityIds(preferred);
                    const signature = JSON.stringify({
                        cono: ctx?.session?.cono,
                        divi: ctx?.session?.divi,
                        entityType: this.selectedEntityType,
                        ids,
                        preferredEntityType: this.preferredEntityType,
                        preferredIds,
                        program: ctx?.program,
                        panel: ctx?.panel,
                        screenId: ctx?.screenId,
                    });
                    if (!selectionChanged && signature === this.lastSignature) {
                        return;
                    }
                    this.lastSignature = signature;
                    Log.info("[tenant.vince.m3.companion] New context signature detected; posting context to current iframe without reload.");
                }
                postContextToIframe() {
                    const iframeWindow = this.iframeRef?.nativeElement?.contentWindow;
                    if (!iframeWindow || !this.pendingContextToPost) {
                        Log.info(`[tenant.vince.m3.companion] Skipping postMessage. iframeWindow=${Boolean(iframeWindow)} pendingContext=${Boolean(this.pendingContextToPost)}`);
                        return;
                    }
                    const targetOrigin = this.getIframeTargetOrigin();
                    if (!targetOrigin) return;
                    Log.info(`[tenant.vince.m3.companion] Posting M3 context to iframe. origin=${targetOrigin}`);
                    iframeWindow.postMessage({
                        type: "vinceHostEvent",
                        event: "inforBusinessContext",
                        data: this.pendingContextToPost,
                    }, targetOrigin);
                }
                getIframeTargetOrigin() {
                    try {
                        const url = new URL(this.url);
                        return url.protocol === 'https:' && !url.username && !url.password ? url.origin : null;
                    }
                    catch {
                        return null;
                    }
                }
                initializeNavigation() {
                    const policy = createBookmarkPolicy(() => this.context);
                    this.navigationHost = createM3NavigationHost({
                        uuid: () => {
                            const bytes = new Uint8Array(24);
                            window.crypto.getRandomValues(bytes);
                            return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
                        },
                        isTrusted: event => {
                            const origin = this.getIframeTargetOrigin();
                            return !!origin && event.origin === origin && event.source === this.iframeRef?.nativeElement?.contentWindow;
                        },
                        // Verified transport must be fixed here before release; no permissive aliases.
                        unwrap: envelope => envelope && envelope.type === 'vinceHostPublish' && envelope.event === 'm3Navigation.request' ? envelope.data : null,
                        send: data => {
                            const origin = this.getIframeTargetOrigin();
                            const child = this.iframeRef?.nativeElement?.contentWindow;
                            if (origin && child) child.postMessage({type:'vinceHostEvent', event:'m3Navigation.response', data}, origin);
                        },
                        available: () => typeof this.widgetContext.launch === 'function' && !!this.getIframeTargetOrigin(),
                        targetProfiles: () => policy.targetProfiles(),
                        targetScopeModes: () => policy.targetScopeModes(),
                        validate: payload => policy.validate(payload),
                        launch: bookmark => this.widgetContext.launch({url: bookmark.url, resolve: false})
                    });
                    this.navigationDiagnostic = 'Waiting for a navigation capability request.';
                    this.navigationListener = event => {
                        const child = this.iframeRef?.nativeElement?.contentWindow;
                        if (this.navigationDiagnosticsEnabled && child && event.source === child && event.origin === this.getIframeTargetOrigin()) {
                            try {
                                const raw = event.data;
                                if (raw && typeof raw === 'object' && JSON.stringify(raw).length <= 16384) {
                                    const paths = [ ['data'], ['payload'], ['message'], ['payload','data'], ['data','data'], ['message','data'] ];
                                    for (const path of paths) {
                                        let candidate = raw;
                                        for (const key of path) candidate = candidate && candidate[key];
                                        if (candidate && candidate.protocol === 'vince.m3.navigation' && candidate.type === 'capabilities.request') {
                                            const metadata = {
                                                origin: event.origin,
                                                envelopeKeys: Object.keys(raw).filter(k => /^[A-Za-z0-9_.-]{1,64}$/.test(k)).slice(0,40),
                                                type: typeof raw.type === 'string' && /^[A-Za-z0-9_.-]{1,80}$/.test(raw.type) ? raw.type : '(not a simple string)',
                                                event: raw.event === 'm3Navigation.request' ? raw.event : '(nested or other)',
                                                payloadPath: path.join('.'),
                                                protocol: candidate.protocol,
                                                version: candidate.version === 1 || candidate.version === 2 ? candidate.version : '(unsupported)',
                                                messageType: candidate.type
                                            };
                                            this.navigationDiagnostic = JSON.stringify(metadata, null, 2);
                                            break;
                                        }
                                    }
                                }
                            } catch (_) { /* Never log arbitrary message contents. */ }
                        }
                        this.navigationHost.receive(event);
                    };
                    window.addEventListener('message', this.navigationListener);
                }

                extractEntityIds(entity) {
                    if (!entity)
                        return {};
                    return Object.entries(entity).reduce((acc, [key, value]) => {
                        if (!/^id\d+$/i.test(key))
                            return acc;
                        const normalized = this.normalizeM3Id(value);
                        if (normalized) {
                            acc[key.toLowerCase()] = normalized;
                        }
                        return acc;
                    }, {});
                }
            };
            __decorate([
                Input(),
                __metadata("design:type", IWidgetInstance)
            ], IonApiM3Component.prototype, "widgetInstance", void 0);
            __decorate([
                ViewChild("contentFrame"),
                __metadata("design:type", ElementRef)
            ], IonApiM3Component.prototype, "iframeRef", void 0);
            IonApiM3Component = __decorate([
                Component({
                    template: `
		<div class="lm-padding-md" style="height: 100%; display: flex; flex-direction: column;">
			<pre *ngIf="navigationDiagnosticsEnabled" style="max-height:180px; overflow:auto; white-space:pre-wrap; font-size:11px;">{{ navigationDiagnostic }}</pre>
			<iframe
				#contentFrame
				[src]="urlSafe"
				(load)="onIframeLoad()"
				(error)="onIframeError()"
				width="100%"
				style="border:none; margin-top: 12px; flex: 1 1 auto; min-height: 0;"
			></iframe>
		</div>
	`,
                }),
                __param(0, Inject(widgetContextInjectionToken)),
                __metadata("design:paramtypes", [IWidgetContext,
                    DomSanitizer])
            ], IonApiM3Component);
            let IonApiM3Module = class IonApiM3Module {
            };
            IonApiM3Module = __decorate([
                NgModule({
                    imports: [CommonModule, FormsModule],
                    declarations: [IonApiM3Component],
                })
            ], IonApiM3Module);

            const widgetFactory = exports('widgetFactory', (widgetContext = null) => {
                const baseEntityOptions = [];
                const createSettingsUi = (settingsContext) => {
                    // The dialog owns the current instance context; do not rely on a stale factory closure.
                    const instanceContext = settingsContext?.getWidgetContext?.() || widgetContext;
                    const settings = instanceContext?.getSettings?.();
                    const read = (key) => typeof settings?.get === 'function' ? settings.get(key) : settings?.[key];
                    const container = settingsContext?.getElement?.();
                    const host = container ? container[0] || container : null;
                    const fallbackTitle = instanceContext?.getTitle?.() || '';
                    const savedBase = read('baseUrl');
                    const effectiveBase = typeof savedBase === 'string' && savedBase.trim() ? savedBase.trim() : DEFAULT_BASE_URL;
                    const savedTitle = read('title');
                    const initialTitle = typeof savedTitle === 'string' ? savedTitle : fallbackTitle;
                    const savedEntity = read('entityType');
                    const initialEntity = typeof savedEntity === 'string' && savedEntity.trim() ? savedEntity : '';
                    const savedOptions = read('entityOptions');
                    const options = new Set([ALL_CONTEXTS_ENTITY_TYPE, ...baseEntityOptions]);
                    if (Array.isArray(savedOptions)) savedOptions.filter(x => typeof x === 'string' && x.trim()).forEach(x => options.add(x));
                    if (initialEntity) options.add(initialEntity); // Never reset a saved, currently undiscovered entity.
                    const initialDiagnostics = read('navigationDiagnostics') === true;
                    const form = document.createElement('div');
                    form.className = 'vince-companion-settings';
                    form.style.width = '100%';
                    const addField = (labelText, control) => {
                        const wrapper = document.createElement('div');
                        wrapper.className = 'field';
                        wrapper.style.width = '100%';
                        wrapper.style.marginBottom = '16px';
                        const label = document.createElement('label');
                        label.textContent = labelText;
                        label.style.display = 'block';
                        // Nesting gives a native accessible label without cross-instance ID collisions.
                        label.appendChild(control);
                        wrapper.appendChild(label);
                        form.appendChild(wrapper);
                        return wrapper;
                    };
                    const textInput = value => {
                        const input = document.createElement('input');
                        input.type = 'text'; input.className = 'input'; input.value = value;
                        Object.assign(input.style, {display:'block', width:'100%', maxWidth:'100%', boxSizing:'border-box', marginTop:'6px'});
                        return input;
                    };
                    const titleInput = textInput(initialTitle);
                    addField('Widget title', titleInput);
                    const baseInput = textInput(effectiveBase);
                    const baseWrapper = addField('Base URL', baseInput);
                    if (!(typeof savedBase === 'string' && savedBase.trim())) {
                        const note = document.createElement('small');
                        note.textContent = 'Using the default Base URL. It is not saved as a custom value unless changed.';
                        baseWrapper.appendChild(note);
                    }
                    const entitySelect = document.createElement('select');
                    // Use a native select: automatic Soho enhancement was replacing it with a narrow, blank control.
                    entitySelect.className = 'vince-companion-entity-select';
                    Object.assign(entitySelect.style, {display:'block', width:'100%', maxWidth:'100%', minWidth:'0', height:'38px', boxSizing:'border-box', marginTop:'6px', padding:'6px 10px'});
                    const addOption = (value, label) => { const option=document.createElement('option'); option.value=value; option.textContent=label; entitySelect.appendChild(option); };
                    if (!initialEntity) addOption('', 'No specific context entity configured');
                    options.forEach(value => addOption(value, value === ALL_CONTEXTS_ENTITY_TYPE ? ALL_CONTEXTS_LABEL : value));
                    entitySelect.value = initialEntity;
                    addField('Context entity', entitySelect);
                    const diagnosticsInput = document.createElement('input');
                    diagnosticsInput.type = 'checkbox';
                    diagnosticsInput.checked = initialDiagnostics;
                    Object.assign(diagnosticsInput.style, {appearance:'auto', width:'16px', height:'16px', margin:'0 8px 0 0', display:'inline-block', position:'static', opacity:'1'});
                    const diagnosticsLabel = document.createElement('label');
                    diagnosticsLabel.appendChild(diagnosticsInput);
                    diagnosticsLabel.appendChild(document.createTextNode('Navigation diagnostics (this widget instance only)'));
                    form.appendChild(diagnosticsLabel);
                    if (host) host.appendChild(form);
                    // No global initialization: these are ordinary native controls with explicit widths.
                    return { closing: arg => {
                        if (!arg?.isSave || typeof settings?.set !== 'function') return;
                        // Save only intentional changes; preserve defaults, unknown values and unrelated settings.
                        if (baseInput.value !== effectiveBase) settings.set('baseUrl', baseInput.value.trim());
                        if (entitySelect.value !== initialEntity) settings.set('entityType', entitySelect.value);
                        if (diagnosticsInput.checked !== initialDiagnostics) settings.set('navigationDiagnostics', diagnosticsInput.checked === true);
                        if (titleInput.value !== initialTitle) {
                            const title = titleInput.value.trim();
                            settings.set('title', title);
                            instanceContext?.setTitle?.(title || fallbackTitle);
                            instanceContext?.setTitleLocked?.(false);
                        }
                    }};
                };
                return {
                    angularConfig: {
                        moduleType: IonApiM3Module,
                        componentType: IonApiM3Component,
                    },
                    widgetSettingsFactory: createSettingsUi,
                };
            });

        })
    };
}));
